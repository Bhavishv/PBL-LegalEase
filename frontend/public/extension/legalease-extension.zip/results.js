const mount = document.getElementById("mount");
const hdrTitle = document.getElementById("hdrTitle");

const SYNC_DEFAULTS_WEB = { webAppUrl: "http://localhost:5173" };

function riskClass(level) {
  const l = (level || "").toLowerCase().replace(/\s+/g, "-");
  if (l.includes("high")) return "risk-high";
  if (l.includes("warning") || l.includes("warn")) return "risk-warn";
  return "";
}

function labelColor(riskLabel) {
  const s = String(riskLabel || "").toLowerCase();
  if (s.includes("high") || s.includes("danger")) return "#fde2e8";
  if (s.includes("careful") || s.includes("review") || s.includes("warning"))
    return "#fef3c7";
  return "#d1fae5";
}

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function renderCard(data, webBase) {
  const score = data.overall_score ?? "—";
  const label = data.risk_label ?? "Unknown";
  const summary = data.contract_summary || "";
  hdrTitle.textContent = `LegalEase · ${data.filename || "Analysis"}`;

  const clauses = [...(data.clauses || [])]
    .filter((c) => c.risk_level && String(c.risk_level).replace("high-risk", "high") !== "safe")
    .sort((a, b) => {
      const ord = { "high-risk": 0, high: 0, warning: 1 };
      const ra = ord[a.risk_level] ?? 2;
      const rb = ord[b.risk_level] ?? 2;
      return ra - rb;
    })
    .slice(0, 8);

  const traps = data.trap_chains || [];

  let trapHtml =
    traps.length === 0
      ? `<p style="margin:0;font-size:0.85rem;color:#64748b">No trap chains flagged.</p>`
      : traps
          .slice(0, 6)
          .map(
            (t) =>
              `<div class="trap-box"><strong>${escapeHtml(t.name)}</strong><br>${escapeHtml(
                t.predicted_consequence || t.description || ""
              )}</div>`
          )
          .join("");

  let clauseHtml =
    clauses.length === 0
      ? `<p style="margin:0;font-size:0.85rem;color:#64748b">No high-severity clauses listed here (still review the summary and score).</p>`
      : `<ul class="clauses">${clauses
          .map(
            (c) =>
              `<li class="${riskClass(c.risk_level)}"><strong>${escapeHtml(String(c.risk_level || "").replace(
                /high-risk/gi,
                "HIGH RISK"
              ))}</strong> — ${escapeHtml((c.text || "").slice(0, 380))}${(c.text || "").length > 380 ? "…" : ""}</li>`
          )
          .join("")}</ul>`;

  const analyzerUrl = `${webBase.replace(/\/+$/, "")}/analyze-website`;
  const homeUrl = `${webBase.replace(/\/+$/, "")}/`;

  mount.innerHTML = `
      <div class="score-row">
        <div class="score">${escapeHtml(score)}/100</div>
        <span class="pill" style="background:${labelColor(label)}">${escapeHtml(label)}</span>
      </div>

      ${summary ? `<section><h2>Plain-language summary</h2><div class="summary">${escapeHtml(summary)}</div></section>` : ""}

      <section>
        <h2>Trap chains</h2>
        ${trapHtml}
      </section>

      <section>
        <h2>Risky clauses preview</h2>
        ${clauseHtml}
      </section>

      <div class="btn-row">
        <a class="btn btn-primary" href="${escapeHtml(analyzerUrl)}">Try demo without extension (URL)</a>
        <a class="btn" style="border:1px solid #cbd5e1;color:#475569;background:#fff" href="${escapeHtml(homeUrl)}">LegalEase Home</a>
      </div>
    `;
}

chrome.storage.local.get(["legalease_last_analysis"]).then(({ legalease_last_analysis }) => {
  if (!legalease_last_analysis?.clauses) {
    mount.innerHTML =
      '<div class="empty">No analysis data found.<br>Open this extension’s popup on an http(s) page and tap <strong>Analyze this page</strong>.</div>';
    hdrTitle.textContent = "LegalEase · No Data";
    return;
  }

  chrome.storage.sync.get(SYNC_DEFAULTS_WEB, (s) => {
    const base =
      typeof s.webAppUrl === "string" && s.webAppUrl.startsWith("http")
        ? s.webAppUrl.replace(/\/+$/, "")
        : SYNC_DEFAULTS_WEB.webAppUrl;
    renderCard(legalease_last_analysis, base);
  });
});
